﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace MovieTicketManagementSystem
{
    public partial class AddStaffsForm : UserControl
    {
        private string connectionString = "User Id=system;Password=12345;Data Source=localhost:1521/xe;"; // Oracle connection string
        private int getID = 0;

        public AddStaffsForm()
        {
            InitializeComponent();
            displayData();
        }

        // Method to display data in the DataGridView
        public void displayData()
        {
            using (OracleConnection connect = new OracleConnection(connectionString))
            {
                try
                {
                    connect.Open();

                    string query = "SELECT id, username, password, role, status, date_reg FROM users ORDER BY id";

                    OracleDataAdapter adapter = new OracleDataAdapter(query, connect);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    dataGridView1.DataSource = table;
                }
                catch (OracleException ex)
                {
                    MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void addstaff_addBtn_Click(object sender, EventArgs e)
        {
            if (isEmpty())
            {
                MessageBox.Show("Empty fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (OracleConnection connect = new OracleConnection(connectionString))
            {
                try
                {
                    connect.Open();

                    // Check if the username already exists
                    string selectUsername = "SELECT COUNT(*) FROM users WHERE username = :usern";

                    using (OracleCommand checkUsern = new OracleCommand(selectUsername, connect))
                    {
                        checkUsern.Parameters.Add(":usern", OracleDbType.Varchar2).Value = addstaff_username.Text.Trim();

                        int userCount = Convert.ToInt32(checkUsern.ExecuteScalar());

                        if (userCount > 0)
                        {
                            MessageBox.Show($"{addstaff_username.Text.Trim()} already exists.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    // Insert the new staff member
                    string insertData = "INSERT INTO users (username, password, role, status, date_reg) " +
                                        "VALUES (:usern, :pass, :role, :status, :date)";

                    using (OracleCommand cmd = new OracleCommand(insertData, connect))
                    {
                        cmd.Parameters.Add(":usern", OracleDbType.Varchar2).Value = addstaff_username.Text.Trim();
                        cmd.Parameters.Add(":pass", OracleDbType.Varchar2).Value = addstaff_password.Text.Trim();
                        cmd.Parameters.Add(":role", OracleDbType.Varchar2).Value = "Staff";
                        cmd.Parameters.Add(":status", OracleDbType.Varchar2).Value = addstaff_status.SelectedItem.ToString();
                        cmd.Parameters.Add(":date", OracleDbType.Date).Value = DateTime.Today;

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Staff added successfully.", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            displayData(); // Refresh the data grid view
                        }
                        else
                        {
                            MessageBox.Show("Failed to add staff.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        clearFields();
                    }
                }
                catch (OracleException ex)
                {
                    MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                getID = Convert.ToInt32(row.Cells[0].Value);
                addstaff_username.Text = row.Cells[1].Value.ToString();
                addstaff_password.Text = row.Cells[2].Value.ToString();
                addstaff_status.SelectedItem = row.Cells[4].Value.ToString();
            }
        }

        private void addstaff_updateBtn_Click(object sender, EventArgs e)
        {
            if (isEmpty())
            {
                MessageBox.Show("Empty fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (DialogResult.Yes == MessageBox.Show("Are you sure you want to update id: " + getID + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {
                using (OracleConnection connect = new OracleConnection(connectionString))
                {
                    try
                    {
                        connect.Open();

                        string selectUsername = "SELECT COUNT(*) FROM users WHERE username = :usern AND id != :id";

                        using (OracleCommand checkUsern = new OracleCommand(selectUsername, connect))
                        {
                            checkUsern.Parameters.Add(":usern", OracleDbType.Varchar2).Value = addstaff_username.Text.Trim();
                            checkUsern.Parameters.Add(":id", OracleDbType.Int32).Value = getID;

                            int userCount = Convert.ToInt32(checkUsern.ExecuteScalar());

                            if (userCount > 0)
                            {
                                MessageBox.Show($"{addstaff_username.Text.Trim()} already exists.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        string updateData = "UPDATE users SET username = :usern, password = :pass, status = :status WHERE id = :id";

                        using (OracleCommand cmd = new OracleCommand(updateData, connect))
                        {
                            cmd.Parameters.Add(":usern", OracleDbType.Varchar2).Value = addstaff_username.Text.Trim();
                            cmd.Parameters.Add(":pass", OracleDbType.Varchar2).Value = addstaff_password.Text.Trim();
                            cmd.Parameters.Add(":status", OracleDbType.Varchar2).Value = addstaff_status.SelectedItem.ToString();
                            cmd.Parameters.Add(":id", OracleDbType.Int32).Value = getID;

                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Update successful.", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                displayData();
                            }
                            else
                            {
                                MessageBox.Show("Update failed.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            clearFields();
                        }
                    }
                    catch (OracleException ex)
                    {
                        MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private bool isEmpty()
        {
            return string.IsNullOrWhiteSpace(addstaff_username.Text) ||
                   string.IsNullOrWhiteSpace(addstaff_password.Text) ||
                   addstaff_status.SelectedItem == null;
        }

        public void clearFields()
        {
            addstaff_username.Text = "";
            addstaff_password.Text = "";
            addstaff_status.SelectedIndex = -1;
        }

        private void addstaff_deleteBtn_Click(object sender, EventArgs e)
        {
            if (isEmpty())
            {
                MessageBox.Show("Empty fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (DialogResult.Yes == MessageBox.Show("Are you sure you want to delete id: " + getID + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
                {
                    using (OracleConnection connect = new OracleConnection(connectionString))
                    {
                        try
                        {
                            connect.Open();

                            string updateData = "UPDATE users SET status = :status WHERE id = :id";

                            using (OracleCommand cmd = new OracleCommand(updateData, connect))
                            {
                                cmd.Parameters.Add(":status", OracleDbType.Varchar2).Value = "Deleted";
                                cmd.Parameters.Add(":id", OracleDbType.Int32).Value = getID;

                                cmd.ExecuteNonQuery();

                                MessageBox.Show("Deleted successfully", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                        catch (OracleException ex)
                        {
                            MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                        catch (Exception ex)
                        {
                            MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            clearFields();

        }

        private void addstaff_clearBtn_Click(object sender, EventArgs e)
        {
            clearFields();
        }
    }

    }
