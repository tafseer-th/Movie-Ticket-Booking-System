﻿using System;
using System.Collections.Generic;
using Oracle.ManagedDataAccess.Client;

namespace MovieTicketManagementSystem
{
    internal class movieData
    {
        private string connectionString = "User Id=system;Password=12345;Data Source=localhost:1521/xe;";

        public int ID { get; set; }
        public string MovieID { get; set; }
        public string MovieName { get; set; }
        public string Genre { get; set; }
        public string Price { get; set; }
        public string Capacity { get; set; }
        public string Image { get; set; }
        public string Status { get; set; }
        public string Date { get; set; }

        public List<movieData> movieListData()
        {
            List<movieData> listData = new List<movieData>();

            using (OracleConnection connect = new OracleConnection(connectionString))
            {
                connect.Open();

                string selectData = "SELECT movie_id, movie_name, genre, price, capacity, status, movie_image, created_at FROM movies WHERE delete_date IS NULL";

                using (OracleCommand cmd = new OracleCommand(selectData, connect))
                {
                    OracleDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        movieData mData = new movieData
                        {
                            MovieID = reader["movie_id"]?.ToString(),
                            MovieName = reader["movie_name"]?.ToString(),
                            Genre = reader["genre"]?.ToString(),
                            Price = reader["price"]?.ToString(),
                            Capacity = reader["capacity"]?.ToString(),
                            Image = reader["movie_image"]?.ToString(),
                            Status = reader["status"]?.ToString(),
                            Date = reader["created_at"]?.ToString()
                        };

                        listData.Add(mData);
                    }
                }
            }
            return listData;
        }
    }
}
