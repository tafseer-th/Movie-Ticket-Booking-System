﻿using System;
using System.Collections.Generic;
using Oracle.ManagedDataAccess.Client; // Oracle namespace
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieTicketManagementSystem
{
    internal class staffData
    {
        private string connectionString = "User Id=system;Password=12345;Data Source=localhost:1521/xe;"; // Oracle connection string

        public int Id { get; set; } // 0
        public string Username { get; set; } // 1
        public string Password { get; set; } // 2
        public string Role { get; set; } // 3
        public string Status { get; set; } // 4

        public List<staffData> staffDataListData()
        {
            List<staffData> listData = new List<staffData>();

            using (OracleConnection connect = new OracleConnection(connectionString))
            {
                connect.Open();

                // Corrected query
                string selectData = "SELECT * FROM users WHERE role = 'Staff' AND status!= 'Deleted'";

                using (OracleCommand cmd = new OracleCommand(selectData, connect))
                {
                    using (OracleDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            staffData sData = new staffData();

                            sData.Id = reader.GetInt32(0); // Use GetInt32 for integers
                            sData.Username = reader.GetString(1); // Use GetString for strings
                            sData.Password = reader.GetString(2);
                            sData.Role = reader.GetString(3);
                            sData.Status = reader.GetString(4);

                            listData.Add(sData);
                        }
                    }
                }
            }

            return listData;
        }
    }
}
