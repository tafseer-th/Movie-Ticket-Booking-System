﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using Oracle.ManagedDataAccess.Client; // Oracle library

namespace MovieTicketManagementSystem
{
    public partial class AddMovieForm : UserControl
    {
        private string connectionString = "User Id=system;Password=12345;Data Source=localhost:1521/xe;"; // Oracle connection string

        public AddMovieForm()
        {
            InitializeComponent();
            displayData();
        }


        public void displayData()
        {
            movieData mData = new movieData();
            List<movieData> listData = mData.movieListData();
            dataGridView1.DataSource = listData;
        }
        private void AddMovieForm_Load(object sender, EventArgs e)
        {
            LoadMovies(); // Load movies when the form loads

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private int id = 0;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                id = (int)row.Cells[0].Value;
                addmovie_movieID.Text = row.Cells[1].Value.ToString();
                addmovie_movieName.Text = row.Cells[2].Value.ToString();
                addmovie_genre.Text = row.Cells[3].Value.ToString();
                addmovie_price.Text = row.Cells[4].Value.ToString();
                addmovie_capacity.Text = row.Cells[5].Value.ToString();
                pictureBox1.ImageLocation = row.Cells[7].Value.ToString();
                addmovie_status.Text = row.Cells[6].Value.ToString();
                
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void addmovie_importBtn_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog file = new OpenFileDialog();
                string imagePath = "";

                file.Filter = "Image Files (*.jpg, *.png)|*.jpg;*.png";

                if (file.ShowDialog() == DialogResult.OK)
                {
                    imagePath = file.FileName;
                    pictureBox1.ImageLocation = imagePath;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex}", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void addMovie_addBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (OracleConnection connect = new OracleConnection(connectionString))
                {
                    connect.Open();

                    string checkID = "SELECT movie_id FROM movies WHERE movie_id = :movieID";

                    using (OracleCommand CID = new OracleCommand(checkID, connect))
                    {
                        CID.Parameters.Add(":movieID", addmovie_movieID.Text.Trim());

                        OracleDataAdapter adapter = new OracleDataAdapter(CID);
                        DataTable table = new DataTable();

                        adapter.Fill(table);

                        if (table.Rows.Count > 0)
                        {
                            MessageBox.Show($"Movie ID: {addmovie_movieID.Text.Trim()} is already taken.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            string insertData = "INSERT INTO movies (movie_id, movie_name, genre, price, capacity, movie_image,status, created_at) " +
                     "VALUES (:movie_id, :movie_name, :genre, :price, :capacity, :movie_image,:status, :created_at)";
                            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
    "MovieDirectory", addmovie_movieID.Text.Trim() + ".jpg");


                            string directoryPath = Path.GetDirectoryName(path);

                            if (!Directory.Exists(directoryPath))
                            {
                                Directory.CreateDirectory(directoryPath);
                            }

                            File.Copy(pictureBox1.ImageLocation, path, true);

                            using (OracleCommand cmd = new OracleCommand(insertData, connect))
                            {
                                cmd.Parameters.Add(":movie_id", addmovie_movieID.Text.Trim());
                                cmd.Parameters.Add(":movie_name", addmovie_movieName.Text.Trim());
                                cmd.Parameters.Add(":genre", addmovie_genre.SelectedItem.ToString());
                                cmd.Parameters.Add(":price", Convert.ToDecimal(addmovie_price.Text.Trim()));
                                cmd.Parameters.Add(":capacity", Convert.ToInt32(addmovie_capacity.Text.Trim()));
                                cmd.Parameters.Add(":movie_image", path);
                                cmd.Parameters.Add(":status", addmovie_status.SelectedItem.ToString());


                                DateTime today = DateTime.Now;
                                cmd.Parameters.Add(":created_at", today);

                                cmd.ExecuteNonQuery();
                                displayData();

                                clearFields();

                                MessageBox.Show("Movie added successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void LoadMovies()
        {
            try
            {
                using (OracleConnection connect = new OracleConnection(connectionString))
                {
                    connect.Open();
                    string selectData = "SELECT movie_id, movie_name, genre, price, capacity,movie_image, status, created_at FROM movies WHERE delete_date IS NULL";
                    using (OracleCommand cmd = new OracleCommand(selectData, connect))
                    {
                        OracleDataAdapter adapter = new OracleDataAdapter(cmd);
                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        dataGridView1.DataSource = table;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void clearFields()
        {
            addmovie_movieID.Text = "";
            addmovie_movieName.Text = "";
            addmovie_genre.SelectedIndex = -1;
            addmovie_price.Text = "";
            addmovie_capacity.Text = "";
            pictureBox1.Image = null;
            addmovie_status.SelectedIndex = -1;
        }

        private void addmovie_clearBtn_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void addmovie_updateBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Are you sure you want to Update ID: " + addmovie_movieID.Text + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    using (OracleConnection connect = new OracleConnection(connectionString))
                    {
                        connect.Open();

                        string checkID = "SELECT COUNT(*) FROM movies WHERE movie_id = :movieID";

                        using (OracleCommand cid = new OracleCommand(checkID, connect))
                        {
                            cid.Parameters.Add(":movieID", addmovie_movieID.Text.Trim());

                            int idCount = Convert.ToInt32(cid.ExecuteScalar());

                            if (idCount > 0)
                            {
                                MessageBox.Show("Movie ID: " + addmovie_movieID.Text.Trim() + " is taken already.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                string updateData = @"
                            UPDATE movies 
                            SET movie_id = :movieID, 
                                movie_name = :moviename, 
                                genre = :genre, 
                                price = :price, 
                                capacity = :capacity, 
                                status = :status, 
                                update_date = :updateDate 
                            WHERE id = :id";

                                using (OracleCommand cmd = new OracleCommand(updateData, connect))
                                {
                                    cmd.Parameters.Add(":movieID", addmovie_movieID.Text.Trim());
                                    cmd.Parameters.Add(":moviename", addmovie_movieName.Text.Trim());
                                    cmd.Parameters.Add(":genre", addmovie_genre.SelectedItem.ToString());
                                    cmd.Parameters.Add(":price", Convert.ToDecimal(addmovie_price.Text.Trim()));
                                    cmd.Parameters.Add(":capacity", Convert.ToInt32(addmovie_capacity.Text.Trim()));
                                    cmd.Parameters.Add(":status", addmovie_status.SelectedItem.ToString());
                                    cmd.Parameters.Add(":updateDate", DateTime.Now);
                                    cmd.Parameters.Add(":id", Convert.ToInt32(id)); // Ensure `id` is of integer type

                                    cmd.ExecuteNonQuery();

                                    displayData();
                                    clearFields();

                                    MessageBox.Show("Updated successfully", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void addmovie_deleteBtn_Click(object sender, EventArgs e)
{
    try
    {
        if (MessageBox.Show($"Are you sure you want to delete Movie ID: {addmovie_movieID.Text}?", 
                            "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
        {
            using (OracleConnection connect = new OracleConnection(connectionString))
            {
                connect.Open();
                        string deleteQuery = "DELETE FROM movies WHERE movie_id = :movieID"; using (OracleCommand cmd = new OracleCommand(deleteQuery, connect))
                {
                            cmd.Parameters.Add(":movieID", addmovie_movieID.Text.Trim());
                    cmd.ExecuteNonQuery();
                }
                displayData();
                clearFields();
                MessageBox.Show("Movie deleted successfully!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}

    }
}

