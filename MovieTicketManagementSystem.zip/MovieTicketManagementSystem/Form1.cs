﻿using System;
using System.Data;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client; // Oracle library

namespace MovieTicketManagementSystem
{
    public partial class Form1 : Form
    {
        private string connectionString = "User Id=system;Password=12345;Data Source=localhost:1521/xe;"; // Oracle connection string

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            RegForm regForm = new RegForm();
            regForm.Show();
            this.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void login_btn_Click(object sender, EventArgs e)
        {
            if (login_username.Text == "" || login_password.Text == "")
            {
                MessageBox.Show("Please fill all blank fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                using (OracleConnection connect = new OracleConnection(connectionString))
                {
                    try
                    {
                        connect.Open();
                        string query = "SELECT * FROM users WHERE username = :username AND password = :password AND status = 'Active'";

                        using (OracleCommand cmd = new OracleCommand(query, connect))
                        {
                            cmd.Parameters.Add(":username", OracleDbType.Varchar2).Value = login_username.Text.Trim();
                            cmd.Parameters.Add(":password", OracleDbType.Varchar2).Value = login_password.Text.Trim();

                            using (OracleDataReader reader = cmd.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    string role = reader["role"].ToString();

                                    if (role == "Admin")
                                    {
                                        MessageBox.Show("Login successful. Welcome, Admin!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        AdminForm adminForm = new AdminForm();
                                        adminForm.Show();
                                    }
                                    else
                                    {
                                        MessageBox.Show("Login successful. Welcome, User!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        // Optionally, navigate to a user-specific screen
                                    }
                                    this.Hide();
                                }
                                else
                                {
                                    MessageBox.Show("Invalid username or password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }



        private void login_showpass_CheckedChanged(object sender, EventArgs e)
        {
            login_password.PasswordChar = login_showpass.Checked ? '\0' : '*';
        }

        private void login_username_TextChanged(object sender, EventArgs e)
        {

        }

        private void close_Click(object sender, EventArgs e)
        {
            // Show confirmation dialog
            DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // Check the user's response
            if (result == DialogResult.Yes)
            {
                Application.Exit(); // Closes the application
            }
            // If "No" is clicked, do nothing
        }

    }
}
