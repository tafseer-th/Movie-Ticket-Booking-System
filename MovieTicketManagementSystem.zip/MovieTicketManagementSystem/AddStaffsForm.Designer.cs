﻿namespace MovieTicketManagementSystem
{
    partial class AddStaffsForm
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.addstaff_deleteBtn = new System.Windows.Forms.Button();
            this.addstaff_updateBtn = new System.Windows.Forms.Button();
            this.addstaff_clearBtn = new System.Windows.Forms.Button();
            this.addstaff_addBtn = new System.Windows.Forms.Button();
            this.addstaff_status = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.addstaff_password = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.addstaff_username = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(305, 25);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(530, 548);
            this.panel2.TabIndex = 3;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(19)))), ((int)(((byte)(33)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(10)))), ((int)(((byte)(56)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.Location = new System.Drawing.Point(19, 57);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Size = new System.Drawing.Size(493, 488);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(16, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 20);
            this.label9.TabIndex = 4;
            this.label9.Text = "All Staff";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.addstaff_deleteBtn);
            this.panel1.Controls.Add(this.addstaff_updateBtn);
            this.panel1.Controls.Add(this.addstaff_clearBtn);
            this.panel1.Controls.Add(this.addstaff_addBtn);
            this.panel1.Controls.Add(this.addstaff_status);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.addstaff_password);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.addstaff_username);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(24, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(261, 548);
            this.panel1.TabIndex = 2;
            // 
            // addstaff_deleteBtn
            // 
            this.addstaff_deleteBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(19)))), ((int)(((byte)(33)))));
            this.addstaff_deleteBtn.FlatAppearance.BorderSize = 0;
            this.addstaff_deleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addstaff_deleteBtn.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addstaff_deleteBtn.ForeColor = System.Drawing.Color.White;
            this.addstaff_deleteBtn.Location = new System.Drawing.Point(26, 364);
            this.addstaff_deleteBtn.Name = "addstaff_deleteBtn";
            this.addstaff_deleteBtn.Size = new System.Drawing.Size(86, 34);
            this.addstaff_deleteBtn.TabIndex = 16;
            this.addstaff_deleteBtn.Text = "DELETE";
            this.addstaff_deleteBtn.UseVisualStyleBackColor = false;
            this.addstaff_deleteBtn.Click += new System.EventHandler(this.addstaff_deleteBtn_Click);
            // 
            // addstaff_updateBtn
            // 
            this.addstaff_updateBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(19)))), ((int)(((byte)(33)))));
            this.addstaff_updateBtn.FlatAppearance.BorderSize = 0;
            this.addstaff_updateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addstaff_updateBtn.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addstaff_updateBtn.ForeColor = System.Drawing.Color.White;
            this.addstaff_updateBtn.Location = new System.Drawing.Point(152, 313);
            this.addstaff_updateBtn.Name = "addstaff_updateBtn";
            this.addstaff_updateBtn.Size = new System.Drawing.Size(86, 34);
            this.addstaff_updateBtn.TabIndex = 15;
            this.addstaff_updateBtn.Text = "UPDATE";
            this.addstaff_updateBtn.UseVisualStyleBackColor = false;
            this.addstaff_updateBtn.Click += new System.EventHandler(this.addstaff_updateBtn_Click);
            // 
            // addstaff_clearBtn
            // 
            this.addstaff_clearBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(19)))), ((int)(((byte)(33)))));
            this.addstaff_clearBtn.FlatAppearance.BorderSize = 0;
            this.addstaff_clearBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addstaff_clearBtn.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addstaff_clearBtn.ForeColor = System.Drawing.Color.White;
            this.addstaff_clearBtn.Location = new System.Drawing.Point(152, 364);
            this.addstaff_clearBtn.Name = "addstaff_clearBtn";
            this.addstaff_clearBtn.Size = new System.Drawing.Size(86, 34);
            this.addstaff_clearBtn.TabIndex = 14;
            this.addstaff_clearBtn.Text = "CLEAR";
            this.addstaff_clearBtn.UseVisualStyleBackColor = false;
            this.addstaff_clearBtn.Click += new System.EventHandler(this.addstaff_clearBtn_Click);
            // 
            // addstaff_addBtn
            // 
            this.addstaff_addBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(19)))), ((int)(((byte)(33)))));
            this.addstaff_addBtn.FlatAppearance.BorderSize = 0;
            this.addstaff_addBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(10)))), ((int)(((byte)(56)))));
            this.addstaff_addBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addstaff_addBtn.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addstaff_addBtn.ForeColor = System.Drawing.Color.White;
            this.addstaff_addBtn.Location = new System.Drawing.Point(26, 313);
            this.addstaff_addBtn.Name = "addstaff_addBtn";
            this.addstaff_addBtn.Size = new System.Drawing.Size(86, 34);
            this.addstaff_addBtn.TabIndex = 13;
            this.addstaff_addBtn.Text = "ADD";
            this.addstaff_addBtn.UseVisualStyleBackColor = false;
            this.addstaff_addBtn.Click += new System.EventHandler(this.addstaff_addBtn_Click);
            // 
            // addstaff_status
            // 
            this.addstaff_status.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addstaff_status.FormattingEnabled = true;
            this.addstaff_status.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.addstaff_status.Location = new System.Drawing.Point(14, 229);
            this.addstaff_status.Name = "addstaff_status";
            this.addstaff_status.Size = new System.Drawing.Size(214, 28);
            this.addstaff_status.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(11, 210);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "Status";
            // 
            // addstaff_password
            // 
            this.addstaff_password.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addstaff_password.Location = new System.Drawing.Point(14, 160);
            this.addstaff_password.Name = "addstaff_password";
            this.addstaff_password.Size = new System.Drawing.Size(214, 25);
            this.addstaff_password.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(11, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "Password";
            // 
            // addstaff_username
            // 
            this.addstaff_username.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addstaff_username.Location = new System.Drawing.Point(14, 94);
            this.addstaff_username.Name = "addstaff_username";
            this.addstaff_username.Size = new System.Drawing.Size(214, 25);
            this.addstaff_username.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(11, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Username";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(22, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Fill Staff Information";
            // 
            // AddStaffsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "AddStaffsForm";
            this.Size = new System.Drawing.Size(860, 599);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button addstaff_deleteBtn;
        private System.Windows.Forms.Button addstaff_updateBtn;
        private System.Windows.Forms.Button addstaff_clearBtn;
        private System.Windows.Forms.Button addstaff_addBtn;
        private System.Windows.Forms.ComboBox addstaff_status;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox addstaff_password;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox addstaff_username;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}
