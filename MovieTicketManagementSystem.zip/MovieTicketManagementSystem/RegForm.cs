﻿using System;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace MovieTicketManagementSystem
{
    public partial class RegForm : Form
    {
        private string connectionString = "User Id=system;Password=12345;Data Source=localhost:1521/xe;";

        public RegForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) // Register Button
        {
            string username = reg_username.Text.Trim();
            string password = reg_password.Text;
            string confirmPassword = reg_cpassword.Text;

            // Input Validation
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirmPassword))
            {
                MessageBox.Show("All fields are required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (password != confirmPassword)
            {
                MessageBox.Show("Passwords do not match!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (OracleConnection connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    string query = "INSERT INTO users (username, password, role, status, date_reg) VALUES (:username, :password, 'User', 'Active', SYSDATE)";

                    using (OracleCommand cmd = new OracleCommand(query, connection))
                    {
                        cmd.Parameters.Add(":username", OracleDbType.Varchar2).Value = username;
                        cmd.Parameters.Add(":password", OracleDbType.Varchar2).Value = password; // Ideally, hash the password here

                        int result = cmd.ExecuteNonQuery();

                        if (result > 0)
                        {
                            MessageBox.Show("Registration successful! You can now log in.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Navigate to the login form (Form1)
                            Form1 loginForm = new Form1();
                            loginForm.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Registration failed. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (OracleException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e) // Show Password
        {
            bool isChecked = checkBox1.Checked;
            reg_password.PasswordChar = isChecked ? '\0' : '*';
            reg_cpassword.PasswordChar = isChecked ? '\0' : '*';
        }

        private void button2_Click(object sender, EventArgs e) // Navigate to Login
        {
            Form1 loginForm = new Form1();
            loginForm.Show();
            this.Hide();
        }

        private void close_Click_1(object sender, EventArgs e) // Close Form
        {
            this.Close();
        }
    }
}
